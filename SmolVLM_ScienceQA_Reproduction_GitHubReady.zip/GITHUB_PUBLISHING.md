# Publishing This Repository on GitHub

This directory is a Git repository with all reproduction code and the selected
result files. The target public repository is:

<https://github.com/zhi906938-web/SmolVLM-ScienceQA-Reproduction>

Then run:

```bash
git remote add origin https://github.com/zhi906938-web/SmolVLM-ScienceQA-Reproduction.git
git branch -M main
git push -u origin main
```


