# SmolVLM ScienceQA Reproduction

Code repository:
<https://github.com/zhi906938-web/SmolVLM-ScienceQA-Reproduction>

Minimal reproduction code for **SmolVLM: Redefining small and efficient
multimodal models** on the image subset of ScienceQA.

Paper: <https://arxiv.org/abs/2504.05299>  
Official code: <https://github.com/huggingface/smollm>

## Scope

This project evaluates released SmolVLM checkpoints on `ScienceQA-IMG` test:

- SmolVLM-256M-Instruct
- SmolVLM-500M-Instruct
- SmolVLM-Instruct (2.2B, optional)

The model weights are frozen. No training or fine-tuning is performed.

The default `vlmeval` prompt format follows the official VLMEvalKit SmolVLM
adapter: it includes the ScienceQA hint, uses the `Choices:` MCQ template, and
feeds the raw SmolVLM conversation markers directly to the processor. The
`simple` format is kept for comparison with the initial trial.

Paper-reported ScienceQA scores:

| Model | ScienceQA |
|---|---:|
| SmolVLM-256M | 73.8% |
| SmolVLM-500M | 80.0% |
| SmolVLM-2.2B | 89.6% |

The local numbers will not be bit-identical because prompt format, image
resolution, decoding settings, and answer parsing can differ.

See [`RESULTS.md`](RESULTS.md) for the completed controlled comparison. With
the VLMEvalKit prompt at a 1,024-pixel image edge, this reproduction reaches
72.73% for 256M and 78.58% for 500M.

## Code and Weights

- Baseline and protocol-aligned weights use the same frozen public checkpoints.
- Model sources and weight details: [`WEIGHTS.md`](WEIGHTS.md).
- Reproduced sample-level results: [`results/`](results/).
- GitHub publication instructions: [`GITHUB_PUBLISHING.md`](GITHUB_PUBLISHING.md).

## Data

The code uses the `ScienceQA-IMG` test split from:

<https://huggingface.co/datasets/lmms-lab/ScienceQA>

It contains 2,017 image-based test questions and their multiple-choice answers.

## Environment

- Python 3.10
- CUDA GPU with at least 8 GB memory
- PyTorch 2.0 or newer
- Transformers 4.46.0 or newer

Install:

```bash
python -m pip install -r requirements.txt
```

If Hugging Face is unavailable, set:

```bash
export HF_ENDPOINT=https://hf-mirror.com
```

## Download Data

```bash
python scripts/download_scienceqa.py
```

## Smoke Test

Start with 20 samples:

```bash
python evaluate_scienceqa.py \
  --model-id HuggingFaceTB/SmolVLM-500M-Instruct \
  --data datasets/scienceqa/test.parquet \
  --limit 20 \
  --image-max-edge 512 \
  --prompt-format vlmeval \
  --dtype float16 \
  --output results/smoke_smolvlm_500m.jsonl
```

## Full Evaluation

256M:

```bash
python evaluate_scienceqa.py \
  --model-id HuggingFaceTB/SmolVLM-256M-Instruct \
  --data datasets/scienceqa/test.parquet \
  --image-max-edge 1800 \
  --prompt-format vlmeval \
  --dtype float16 \
  --output results/scienceqa_smolvlm_256m.jsonl
```

500M:

```bash
python evaluate_scienceqa.py \
  --model-id HuggingFaceTB/SmolVLM-500M-Instruct \
  --data datasets/scienceqa/test.parquet \
  --image-max-edge 1800 \
  --prompt-format vlmeval \
  --dtype float16 \
  --output results/scienceqa_smolvlm_500m.jsonl
```

Optional 2.2B:

```bash
python evaluate_scienceqa.py \
  --model-id HuggingFaceTB/SmolVLM-Instruct \
  --data datasets/scienceqa/test.parquet \
  --image-max-edge 1536 \
  --prompt-format vlmeval \
  --dtype float16 \
  --output results/scienceqa_smolvlm_2b.jsonl
```

## Summarize

```bash
python summarize_results.py results/*.jsonl
```

## Output

Each JSONL record contains:

- sample index
- question and choices
- ground-truth letter
- generated text
- parsed prediction letter
- correctness
- per-sample latency

The summary reports accuracy, unparsed answers, and average latency.

## Hardware Notes

The paper reports approximately:

| Model | GPU memory at batch size 1 |
|---|---:|
| SmolVLM-256M | 0.8 GB |
| SmolVLM-500M | 1.2 GB |
| SmolVLM-2.2B | 4.9 GB |

An RTX 3080 10 GB should run all three, although a larger image resolution and
long generation length increase memory use.
