# Reproduction Results

Each JSONL file contains one JSON object per ScienceQA-IMG test sample.

- `scienceqa_smolvlm_256m_vlmeval_1024.jsonl`
- `scienceqa_smolvlm_500m_vlmeval_1024.jsonl`

The corresponding summary files contain accuracy, correct count, unparsed count,
image resolution, prompt format, and mean latency.

Main results:

| Model | Correct | Samples | Accuracy | Unparsed |
|---|---:|---:|---:|---:|
| SmolVLM-256M | 1467 | 2017 | 72.73% | 0 |
| SmolVLM-500M | 1585 | 2017 | 78.58% | 0 |

