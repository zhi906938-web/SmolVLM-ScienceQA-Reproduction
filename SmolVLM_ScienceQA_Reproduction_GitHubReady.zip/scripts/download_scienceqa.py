from __future__ import annotations

import argparse
import urllib.request
from pathlib import Path


FILENAME = "test-00000-of-00001.parquet"
DEFAULT_URL = (
    "https://huggingface.co/datasets/lmms-lab/ScienceQA/resolve/main/"
    f"ScienceQA-IMG/{FILENAME}"
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Download ScienceQA-IMG test.")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("datasets/scienceqa"),
    )
    parser.add_argument(
        "--endpoint",
        default="https://huggingface.co",
        help="Use https://hf-mirror.com when Hugging Face is unavailable.",
    )
    args = parser.parse_args()
    url = DEFAULT_URL.replace("https://huggingface.co", args.endpoint)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    target = args.output_dir / "test.parquet"
    if target.exists() and target.stat().st_size > 0:
        print(f"exists: {target}")
        return 0
    print(f"download: {url}")
    urllib.request.urlretrieve(url, target)
    print(f"wrote: {target} ({target.stat().st_size} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
