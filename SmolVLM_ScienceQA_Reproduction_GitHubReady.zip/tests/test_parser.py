import unittest

from scienceqa_utils import build_prompt, parse_prediction


class ParserTest(unittest.TestCase):
    def test_parse_letter(self):
        self.assertEqual(parse_prediction("B", ["one", "two"]), "B")
        self.assertEqual(parse_prediction("Answer: C.", ["one", "two", "three"]), "C")

    def test_parse_choice_text(self):
        self.assertEqual(
            parse_prediction(
                "The plant will dry out.",
                ["The plant will grow", "The plant will dry out"],
            ),
            "B",
        )

    def test_prompt_contains_choices(self):
        prompt = build_prompt(
            "What happens?",
            ["grow", "dry out"],
            prompt_format="simple",
        )
        self.assertIn("A. grow", prompt)
        self.assertIn("B. dry out", prompt)
        self.assertTrue(prompt.endswith("Answer:"))

    def test_vlmeval_prompt(self):
        prompt = build_prompt(
            "What happens?",
            ["grow", "dry out"],
            hint="The plant has no water.",
        )
        self.assertTrue(prompt.startswith("Hint: The plant has no water."))
        self.assertIn("Question: What happens?", prompt)
        self.assertIn("Choices:", prompt)
        self.assertTrue(prompt.endswith("Answer with the letter."))


if __name__ == "__main__":
    unittest.main()
