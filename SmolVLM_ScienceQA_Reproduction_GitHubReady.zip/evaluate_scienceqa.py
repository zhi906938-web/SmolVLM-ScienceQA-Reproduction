from __future__ import annotations

import argparse
import json
import time
from io import BytesIO
from pathlib import Path
from typing import Any

import pandas as pd
import torch
from PIL import Image
from tqdm import tqdm
from transformers import AutoModelForVision2Seq, AutoProcessor

from scienceqa_utils import LETTERS, build_prompt, parse_prediction


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Evaluate SmolVLM on the ScienceQA-IMG test split."
    )
    parser.add_argument(
        "--model-id",
        default="HuggingFaceTB/SmolVLM-500M-Instruct",
    )
    parser.add_argument(
        "--data",
        type=Path,
        default=Path("datasets/scienceqa/test.parquet"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results/scienceqa_smolvlm.jsonl"),
    )
    parser.add_argument("--limit", type=int)
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--max-new-tokens", type=int, default=8)
    parser.add_argument("--image-max-edge", type=int, default=512)
    parser.add_argument(
        "--prompt-format",
        default="vlmeval",
        choices=("vlmeval", "simple"),
    )
    parser.add_argument(
        "--attn-implementation",
        default="eager",
        choices=("eager", "sdpa"),
    )
    parser.add_argument(
        "--dtype",
        default="float16",
        choices=("bfloat16", "float16", "float32"),
    )
    parser.add_argument("--continue-on-error", action="store_true")
    return parser.parse_args()


def image_from_payload(payload: Any) -> Image.Image:
    if isinstance(payload, dict):
        payload = payload.get("bytes") or payload.get("path")
    if isinstance(payload, bytes):
        return Image.open(BytesIO(payload)).convert("RGB")
    if isinstance(payload, str):
        return Image.open(payload).convert("RGB")
    raise TypeError(f"unsupported image payload: {type(payload).__name__}")


def resolve_dtype(name: str) -> torch.dtype:
    return {
        "bfloat16": torch.bfloat16,
        "float16": torch.float16,
        "float32": torch.float32,
    }[name]


def main() -> int:
    args = parse_args()
    if not args.data.exists():
        raise FileNotFoundError(
            f"data file not found: {args.data}. Run scripts/download_scienceqa.py."
        )
    frame = pd.read_parquet(args.data)
    if args.limit is not None:
        frame = frame.iloc[args.start : args.start + args.limit]
    else:
        frame = frame.iloc[args.start :]

    processor = AutoProcessor.from_pretrained(args.model_id)
    if hasattr(processor, "image_processor"):
        processor.image_processor.size = {
            "longest_edge": int(args.image_max_edge)
        }

    dtype = resolve_dtype(args.dtype)
    model = AutoModelForVision2Seq.from_pretrained(
        args.model_id,
        torch_dtype=dtype,
        low_cpu_mem_usage=True,
        attn_implementation=args.attn_implementation,
    )
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for this evaluation")
    device = torch.device("cuda")
    model.to(device)
    model.eval()
    print(
        f"loaded model on {device} with dtype {dtype}",
        flush=True,
    )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    output = args.output.open("w", encoding="utf-8")
    correct = 0
    unparsed = 0
    processed = 0
    total_latency = 0.0
    try:
        for sample_index, (_, row) in enumerate(
            tqdm(frame.iterrows(), total=len(frame), desc=args.model_id),
            start=args.start,
        ):
            try:
                image = image_from_payload(row["image"])
                choices = [str(choice) for choice in row["choices"]]
                question = str(row["question"])
                hint_value = row.get("hint")
                hint = (
                    str(hint_value).strip()
                    if hint_value is not None
                    and not pd.isna(hint_value)
                    else None
                )
                prompt_text = build_prompt(
                    question,
                    choices,
                    hint=hint,
                    prompt_format=args.prompt_format,
                )
                if args.prompt_format == "vlmeval":
                    prompt = (
                        f"<|im_start|>User:<image>{prompt_text}"
                        "<end_of_utterance>\nAssistant: Answer:"
                    )
                else:
                    messages = [
                        {
                            "role": "user",
                            "content": [
                                {"type": "image"},
                                {"type": "text", "text": prompt_text},
                            ],
                        }
                    ]
                    prompt = processor.apply_chat_template(
                        messages,
                        add_generation_prompt=True,
                    )
                inputs = processor(
                    text=prompt,
                    images=[image],
                    return_tensors="pt",
                )
                inputs = {
                    key: value.to(device) if torch.is_tensor(value) else value
                    for key, value in inputs.items()
                }

                started = time.perf_counter()
                with torch.inference_mode():
                    generated = model.generate(
                        **inputs,
                        max_new_tokens=args.max_new_tokens,
                        do_sample=False,
                    )
                latency = time.perf_counter() - started
                prompt_length = inputs["input_ids"].shape[1]
                new_tokens = generated[:, prompt_length:]
                raw_text = processor.batch_decode(
                    new_tokens,
                    skip_special_tokens=True,
                    clean_up_tokenization_spaces=True,
                )[0].strip()
                prediction = parse_prediction(raw_text, choices)
                gold_index = int(row["answer"])
                gold_letter = LETTERS[gold_index]
                is_correct = prediction == gold_letter
                correct += int(is_correct)
                unparsed += int(prediction is None)
                processed += 1
                total_latency += latency
                record = {
                    "index": sample_index,
                    "question": question,
                    "hint": hint,
                    "choices": choices,
                    "gold": gold_letter,
                    "prediction": prediction,
                    "correct": is_correct,
                    "raw_text": raw_text,
                    "latency_seconds": latency,
                    "model_id": args.model_id,
                }
            except Exception as error:
                if not args.continue_on_error:
                    raise
                record = {
                    "index": sample_index,
                    "error": f"{type(error).__name__}: {error}",
                    "model_id": args.model_id,
                }
            output.write(json.dumps(record, ensure_ascii=False) + "\n")
            output.flush()
    finally:
        output.close()

    summary = {
        "model_id": args.model_id,
        "samples": processed,
        "correct": correct,
        "accuracy": correct / processed if processed else 0.0,
        "unparsed": unparsed,
        "average_latency_seconds": total_latency / processed if processed else None,
        "image_max_edge": args.image_max_edge,
        "max_new_tokens": args.max_new_tokens,
        "prompt_format": args.prompt_format,
        "dtype": args.dtype,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    summary_path = args.output.with_suffix(".summary.json")
    summary_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
