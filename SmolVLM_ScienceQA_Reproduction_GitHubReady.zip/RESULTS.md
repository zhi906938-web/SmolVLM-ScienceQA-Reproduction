# ScienceQA Reproduction Results

## Setup

- Benchmark: ScienceQA-IMG test split
- Samples: 2,017
- GPU: NVIDIA GeForce RTX 3080 10 GB
- Precision: FP16
- Attention: eager
- Image longest edge: 1,024 pixels
- Prompt: VLMEvalKit SmolVLM `puremcq` format
- Decoding: greedy, maximum 8 new tokens

The prompt includes ScienceQA hints and follows the official VLMEvalKit
SmolVLM adapter. The official paper evaluates 256M and 500M checkpoints at an
image longest edge of 1,920 pixels; this reproduction uses 1,024 pixels because
the shared GPU did not have enough free memory at 1,800 pixels.

## Main Results

| Model | Paper | Reproduced | Difference |
|---|---:|---:|---:|
| SmolVLM-256M-Instruct | 73.8% | 72.73% | -1.07 pp |
| SmolVLM-500M-Instruct | 80.0% | 78.58% | -1.42 pp |

Both runs parsed every answer (`0` unparsed). The gap is therefore not caused
by answer extraction failures.

## Ablation

An initial 256M run used a custom chat-template prompt without ScienceQA hints
and reached only 58.95%. Switching to the VLMEvalKit `puremcq` prompt raised it
to 72.73%, showing that prompt construction is a major evaluation variable for
small VLMs.

| Model | Prompt | Image edge | Accuracy |
|---|---|---:|---:|
| 256M | Custom chat prompt | 1,024 | 58.95% |
| 256M | VLMEvalKit prompt | 1,024 | 72.73% |
| 500M | Custom chat prompt | 1,800 | 69.80% |
| 500M | VLMEvalKit prompt | 1,024 | 78.58% |

The custom-prompt rows are ablations only; they are not directly comparable
across models because their image resolutions differ.

## Reproduction Commands

256M:

```bash
python evaluate_scienceqa.py \
  --model-id HuggingFaceTB/SmolVLM-256M-Instruct \
  --data datasets/scienceqa/test.parquet \
  --image-max-edge 1024 \
  --max-new-tokens 8 \
  --dtype float16 \
  --attn-implementation eager \
  --prompt-format vlmeval \
  --output results/scienceqa_smolvlm_256m_vlmeval_1024.jsonl
```

500M:

```bash
python evaluate_scienceqa.py \
  --model-id HuggingFaceTB/SmolVLM-500M-Instruct \
  --data datasets/scienceqa/test.parquet \
  --image-max-edge 1024 \
  --max-new-tokens 8 \
  --dtype float16 \
  --attn-implementation eager \
  --prompt-format vlmeval \
  --output results/scienceqa_smolvlm_500m_vlmeval_1024.jsonl
```

## Conclusion

The results support the paper's relative model scaling on ScienceQA. The 500M
checkpoint outperforms 256M by 5.85 percentage points in this controlled
comparison (paper: 6.2 points). Absolute scores are within approximately
1.1-1.4 points of the paper despite using a lower image resolution.

