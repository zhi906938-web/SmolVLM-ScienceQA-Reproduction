# Model Weights and Evaluation Resources

This reproduction uses frozen public checkpoints. The protocol-aligned method
changes only prompt construction and answer parsing, so the baseline and the
protocol-aligned evaluation use the same model weights.

| Role | Model | Source |
|---|---|---|
| Baseline | SmolVLM-256M-Instruct | https://huggingface.co/HuggingFaceTB/SmolVLM-256M-Instruct |
| Baseline | SmolVLM-500M-Instruct | https://huggingface.co/HuggingFaceTB/SmolVLM-500M-Instruct |
| Protocol-aligned evaluation | SmolVLM-256M-Instruct | Same checkpoint |
| Protocol-aligned evaluation | SmolVLM-500M-Instruct | Same checkpoint |

No new training weights are produced by this project. The method contribution
is the reconstruction and analysis of the evaluation protocol, not a fine-tuned
model checkpoint.

Official code:

- SmolVLM: https://github.com/huggingface/smollm
- VLMEvalKit: https://github.com/open-compass/VLMEvalKit

