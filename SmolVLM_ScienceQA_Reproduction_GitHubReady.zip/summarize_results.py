from __future__ import annotations

import argparse
import json
from pathlib import Path


def summarize(path: Path) -> dict:
    rows = [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    valid = [row for row in rows if "gold" in row and "prediction" in row]
    correct = sum(int(row["correct"]) for row in valid)
    unparsed = sum(int(row["prediction"] is None) for row in valid)
    latencies = [
        float(row["latency_seconds"])
        for row in valid
        if row.get("latency_seconds") is not None
    ]
    return {
        "file": str(path),
        "model_id": valid[0]["model_id"] if valid else None,
        "samples": len(valid),
        "correct": correct,
        "accuracy": correct / len(valid) if valid else 0.0,
        "unparsed": unparsed,
        "average_latency_seconds": (
            sum(latencies) / len(latencies) if latencies else None
        ),
        "errors": len(rows) - len(valid),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Summarize ScienceQA result files.")
    parser.add_argument("inputs", nargs="+", type=Path)
    args = parser.parse_args()
    rows = [summarize(path) for path in args.inputs]
    print("| Model | Samples | Accuracy | Unparsed | Avg latency |")
    print("|---|---:|---:|---:|---:|")
    for row in rows:
        accuracy = f"{row['accuracy'] * 100:.2f}%"
        latency = (
            f"{row['average_latency_seconds']:.3f}s"
            if row["average_latency_seconds"] is not None
            else "-"
        )
        print(
            f"| {row['model_id']} | {row['samples']} | {accuracy} | "
            f"{row['unparsed']} | {latency} |"
        )
    print(json.dumps(rows, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
