from __future__ import annotations

import re


LETTERS = "ABCDE"


def build_prompt(
    question: str,
    choices: list[str],
    hint: str | None = None,
    prompt_format: str = "vlmeval",
) -> str:
    if prompt_format == "vlmeval":
        lines = []
        if hint:
            lines.append(f"Hint: {hint.strip()}")
        lines.extend(
            [
                f"Question: {question.strip()}",
                "Choices:",
            ]
        )
        lines.extend(
            f"{LETTERS[index]}. {choice}"
            for index, choice in enumerate(choices)
        )
        lines.append("Answer with the letter.")
        return "\n".join(lines)

    if prompt_format != "simple":
        raise ValueError(f"unknown prompt format: {prompt_format}")

    options = "\n".join(
        f"{LETTERS[index]}. {choice}" for index, choice in enumerate(choices)
    )
    return (
        "Answer the following multiple-choice science question based on the image.\n"
        "Respond with only the letter of the correct option.\n\n"
        f"Question: {question}\n"
        f"Options:\n{options}\n"
        "Answer:"
    )


def parse_prediction(text: str, choices: list[str]) -> str | None:
    normalized = text.strip().upper()
    match = re.search(r"\b([A-E])\b", normalized)
    if match:
        return match.group(1)
    lowered = text.lower().strip()
    for index, choice in enumerate(choices):
        choice_text = str(choice).strip().lower()
        if choice_text and choice_text in lowered:
            return LETTERS[index]
    return None
